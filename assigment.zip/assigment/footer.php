<section class="footer">
        <div class="footer-container">
            <img src="image/logo.jpg" height="90px">
             <h4>ABC Construction</h4>

            <div class="icon">
                <h5>Follow us on:</h5>
                <a href="#"><img src="image/facebook.png" height="30px"></a>
                <a href="#"><img src="image/whatsapp.png" height="30px"></a>
                <a href="#"><img src="image/instagram.png" height="30px"></a>
                <a href="#"><img src="image/twitter.png" height="30px"></a>
                
            </div>
        </div>
        <div class ="content">
           


        <div class="footer-container">
            <h4>Product</h4>
            <li id="list2"><a href="#">Package</a></li>
            <li id="list2"><a href="FAQ.html">FAQ</a></li>
        </div>

        <div class="footer-container">
            <h4>Company</h4>
            <li id="list2"><a href="#">About</a></li>
            <li id="list2"><a href="#">Contact us</a></li>
            <li id="list2"><a href="#">Feedbacks</a></li>
        </div>

        <div class="footer-container">
            <h4>Legal</h4>
            <li id="list2"><a href="#">Privacy</a></li>
            <li id="list2"><a href="#">Terms & Conditions</a></li>
        </div>
        
        <div class="footer-container">
            <h4>Get the latest news and updates</h4>
            <p>Lorem ipsum dolor sit amet consectetur 
                adipisicing elit. <br>Fuga sunt enim harum 
                ut esse sint a tempore,</p>
            <input type="text" placeholder="Enter your Email" id="text2">
            <button class="sub-btn">Subscribe</button>
            
        </div>
</section>
</body>
</html>





