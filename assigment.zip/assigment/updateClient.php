<?php
require '../assigment/Include/config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Fetching updated values
    $id = $_POST['id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $price = $_POST['price'];
    $details = $_POST['details'];

    // Update query
    $sql = "UPDATE client_data SET clientName='$name', phoneNumber='$phone', email='$email', address='$address', estimatedPrice='$price', projectDescription='$details' WHERE ID='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Record updated successfully'); window.location.href = 'displayClientData.php';</script>";
    } else {
        echo "<script>alert('Error updating record: " . addslashes($conn->error) . "'); window.history.back();</script>";
    }
}

// Fetch existing client data for the form
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM client_data WHERE ID='$id'");
    $client = $result->fetch_assoc();
} else {
    echo "No ID provided!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Client</title>
    <link rel="stylesheet" href="styles/Style.css"> <!-- header and footer stylesheet -->
    <link rel="stylesheet" href="styles/form.css"> <!-- Update form style stylesheet-->
</head>
<body>
    <?php
        require'header.php';
    ?>
    <h1>Update Client</h1>
    <form method="POST">
        <input type="hidden" name="id" value="<?php echo $client['ID']; ?>">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($client['clientName']); ?>" required>
        <label>Phone Number:</label>
        <input type="text" name="phone" value="<?php echo htmlspecialchars($client['phoneNumber']); ?>" required>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($client['email']); ?>" required>
        <label>Address:</label>
        <input type="text" name="address" value="<?php echo htmlspecialchars($client['address']); ?>" required>
        <label>Estimated Price:</label>
        <input type="text" name="price" value="<?php echo htmlspecialchars($client['estimatedPrice']); ?>" required>
        <label>Project Description:</label>
        <textarea name="details" required><?php echo htmlspecialchars($client['projectDescription']); ?></textarea>
        <button type="submit" class="update">Update</button>
    </form>
    <?php
        require'footer.php';
    ?>
</body>
</html>
