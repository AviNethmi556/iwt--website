<?php
    //connecting php file and database

    //creating variables to store database connection details
    $hostName = "localhost";//name of the server in host database
    $userName = "root";// server user account name
    $userPassword = "";
    $database = "client_info";

    //creating connection to the database
    $conn = new mysqli($hostName,$userName,$userPassword,$database);

    if($conn -> connect_error)
    {
        die("connection error".$conn -> connect_error);
    }
    else{
        echo "<script>alert('Connection successful')</script>";
    }
?>