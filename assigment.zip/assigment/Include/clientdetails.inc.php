<?php
// Linking the connection file
require 'config.php';

// Fetching user inputs directly
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$address = $_POST['address'];
$price = $_POST['price'];
$details = $_POST['details'];

// Construct the SQL INSERT query
$sql = "INSERT INTO client_data (clientName, phoneNumber, email, address, estimatedPrice, projectDescription)
        VALUES ('$name', '$phone', '$email', '$address', '$price', '$details')";

// Execute the query and check for success
if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Submitted successfully'); window.location.href = '../adminpage.html';</script>";
} else {
    echo "<script>alert('Failed to submit. Error: " . addslashes($conn->error) . "'); window.history.back();</script>";
}

// Close the database connection
$conn->close();
?>
