 <!--front page-->
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Construction Management System</title>
    <link rel="icon" type="image/png" href="image/favicon.png"> 
    <link rel="stylesheet" href="styles/Style.css"></link>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" >
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="image/logo.jpg" height="90px">
            <h5>ABC Constructions</h5><br>
        </div>
        <nav>
            <ul>
                <li id="list1"><a href="#">Home</a></li>
                <li id="list1"><a href="">About</a></li>
                <li id="list1"><a href="">Services</a></li>
                <li id="list1"><a href="">Contact us</a></li>
                <li id="list1"><a href="feedback.html">Feedbacks</a></li>
                <button id="btn1"><a href="" ><span>Log in</span></a></button>
                <button id="btn2"><a href=""><span>Sign up</span></a></button>
            </ul>
        </nav>
    </div>
    <div class="search-box"></div>
        <div class="row">
            
            <input type="text" id="input-box" placeholder="Search..." autocomplete="off">
            <button><i class="fa fa-search" aria-hidden="true"></i></button>
        </div>
    </div><br><br>
         

</div>     