<?php
require '../assigment/Include/config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete query
    $sql = "DELETE FROM client_data WHERE ID='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Record deleted successfully'); window.location.href = 'displayClientData.php';</script>";
    } else {
        echo "<script>alert('Error deleting record: " . addslashes($conn->error) . "'); window.history.back();</script>";
    }
} else {
    echo "No ID provided!";
    exit;
}

// Close the database connection
$conn->close();
?>
