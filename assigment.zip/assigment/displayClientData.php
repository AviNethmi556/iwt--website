<?php
// Linking the connection file
require '../assigment/Include/config.php';

// Fetching all client data
$sql = "SELECT * FROM client_data";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Data</title>
    <link rel="stylesheet" href="styles/Style.css"> <!-- Add your CSS here -->
    <link rel="stylesheet" href="styles/tableStyle.css"> <!-- Add your CSS here -->
</head>
<body>
    <?php 
        require'header.php'
    ?>
    <h1>Client Data</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Address</th>
                <th>Estimated Price</th>
                <th>Project Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['ID']; ?></td>
                    <td><?php echo htmlspecialchars($row['clientName']); ?></td>
                    <td><?php echo htmlspecialchars($row['phoneNumber']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['address']); ?></td>
                    <td><?php echo htmlspecialchars($row['estimatedPrice']); ?></td>
                    <td><?php echo htmlspecialchars($row['projectDescription']); ?></td>
                    <td>
                        <a href="updateClient.php?id=<?php echo $row['ID']; ?>">Update</a>
                        <a href="deleteClient.php?id=<?php echo $row['ID']; ?>" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php
        require 'footer.php';
    ?>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
